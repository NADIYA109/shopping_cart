import '../../models/product_model.dart';

abstract class CartState {}

class CartInitial extends CartState {}

class CartUpdated extends CartState {
  final List<Product> cartItems;
  final double totalPrice;

  CartUpdated({required this.cartItems, required this.totalPrice});
}
