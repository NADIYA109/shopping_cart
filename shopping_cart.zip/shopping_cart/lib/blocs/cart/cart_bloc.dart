import 'package:flutter_bloc/flutter_bloc.dart';
import '../../models/product_model.dart';
import 'cart_event.dart';
import 'cart_state.dart';

class CartBloc extends Bloc<CartEvent, CartState> {
  List<Product> cartItems = [];

  CartBloc() : super(CartInitial()) {
    on<AddToCart>((event, emit) {
      cartItems.add(event.product);
      emit(CartUpdated(cartItems: cartItems, totalPrice: _calculateTotal()));
    });

    on<RemoveFromCart>((event, emit) {
      cartItems.remove(event.product);
      emit(CartUpdated(cartItems: cartItems, totalPrice: _calculateTotal()));
    });
  }

  double _calculateTotal() {
    return cartItems.fold(0, (sum, item) => sum + item.finalPrice);
  }
}
