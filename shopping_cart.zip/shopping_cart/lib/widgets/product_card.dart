import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/product_model.dart';
import '../blocs/cart/cart_bloc.dart';
import '../blocs/cart/cart_event.dart';

class ProductCard extends StatelessWidget {
  final Product product;

  const ProductCard({Key? key, required this.product}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: Image.network(product.thumbnail, width: 60, height: 60, fit: BoxFit.cover),
        title: Text(product.title, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text("\$${product.finalPrice.toStringAsFixed(2)}", style: TextStyle(color: Colors.green)),
        trailing: IconButton(
          icon: Icon(Icons.add_shopping_cart, color: Colors.blue),
          onPressed: () {
            context.read<CartBloc>().add(AddToCart(product));
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Added to cart!")));
          },
        ),
      ),
    );
  }
}
